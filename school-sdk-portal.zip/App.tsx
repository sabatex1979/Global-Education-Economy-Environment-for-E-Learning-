
import React, { useState, useCallback } from 'react';
import { User, Course } from './types';
import { MOCK_COURSES, MOCK_USER } from './constants';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [courses] = useState<Course[]>(MOCK_COURSES);

  const handleLogin = useCallback((user: User) => {
    setCurrentUser(user);
    setIsAuthenticated(true);
  }, []);

  const handleLogout = useCallback(() => {
    setIsAuthenticated(false);
    setCurrentUser(null);
  }, []);

  const handleSignUp = useCallback((user: User) => {
    // In a real app, this would involve an API call.
    // For this mock, we'll just log them in.
    setCurrentUser(user);
    setIsAuthenticated(true);
  }, []);

  return (
    <div className="min-h-screen bg-brand-light">
      {isAuthenticated && currentUser ? (
        <Dashboard user={currentUser} courses={courses} onLogout={handleLogout} />
      ) : (
        <Auth onLogin={handleLogin} onSignUp={handleSignUp} />
      )}
    </div>
  );
};

export default App;
