
import React, { useState } from 'react';
import { User } from '../types';
import Login from './Login';
import SignUp from './SignUp';

interface AuthProps {
  onLogin: (user: User) => void;
  onSignUp: (user: User) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin, onSignUp }) => {
  const [isLoginView, setIsLoginView] = useState(true);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="w-full max-w-md p-8 space-y-8 bg-white rounded-2xl shadow-lg">
        <div className="text-center">
            <h1 className="text-3xl font-extrabold text-gray-900">School Portal</h1>
            <p className="mt-2 text-sm text-gray-600">
                {isLoginView ? 'Welcome back! Please sign in.' : 'Create your account to get started.'}
            </p>
        </div>
        {isLoginView ? (
          <Login onLogin={onLogin} />
        ) : (
          <SignUp onSignUp={onSignUp} />
        )}
        <div className="text-sm text-center">
          <button
            onClick={() => setIsLoginView(!isLoginView)}
            className="font-medium text-brand-primary hover:text-brand-dark"
          >
            {isLoginView ? 'Don\'t have an account? Sign up' : 'Already have an account? Sign in'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Auth;
