
import React from 'react';
import { Course } from '../types';

interface CourseCardProps {
  course: Course;
  onSelectCourse: (course: Course) => void;
}

const CourseCard: React.FC<CourseCardProps> = ({ course, onSelectCourse }) => {
  return (
    <div 
      className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-1 transition-all duration-300 cursor-pointer flex flex-col"
      onClick={() => onSelectCourse(course)}
    >
      <img className="h-48 w-full object-cover" src={course.imageUrl} alt={course.title} />
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-xl font-bold text-gray-900 mb-2">{course.title}</h3>
        <p className="text-sm text-gray-600 mb-4">By {course.instructor}</p>
        <p className="text-gray-700 text-base flex-grow">{course.description}</p>
        <button className="mt-4 w-full bg-brand-primary text-white font-semibold py-2 px-4 rounded-lg hover:bg-brand-dark transition-colors">
          View Course
        </button>
      </div>
    </div>
  );
};

export default CourseCard;
