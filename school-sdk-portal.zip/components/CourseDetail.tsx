
import React, { useState } from 'react';
import { Course, VideoLesson } from '../types';
import { PlayIcon, DocumentDownloadIcon, ArrowLeftIcon } from './Icons';
import VideoPlayer from './VideoPlayer';


interface CourseDetailProps {
  course: Course;
  onBack: () => void;
}

const CourseDetail: React.FC<CourseDetailProps> = ({ course, onBack }) => {
  const [currentLesson, setCurrentLesson] = useState<VideoLesson | null>(course.lessons[0] || null);
  
  return (
    <div className="max-w-7xl mx-auto">
      <button
        onClick={onBack}
        className="flex items-center mb-6 text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
      >
        <ArrowLeftIcon className="h-5 w-5 mr-2" />
        Back to Courses
      </button>

      <div className="bg-white rounded-lg shadow-xl overflow-hidden">
        <div className="p-8">
            <h1 className="text-4xl font-extrabold text-gray-900">{course.title}</h1>
            <p className="text-lg text-gray-600 mt-2">By {course.instructor}</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 p-8">
          <div className="lg:col-span-2">
            {currentLesson ? (
              <VideoPlayer videoUrl={currentLesson.videoUrl} title={currentLesson.title} />
            ) : (
                <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center">
                    <p className="text-white">Select a lesson to begin.</p>
                </div>
            )}
            <div className="mt-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">About this course</h2>
                <p className="text-gray-700">{course.longDescription}</p>
            </div>
             <div className="mt-6">
              <h3 className="text-xl font-bold text-gray-800 mb-3">Resources</h3>
              <ul className="space-y-2">
                {course.resources.map(resource => (
                  <li key={resource.name}>
                    <a href={resource.url} className="flex items-center text-brand-primary hover:underline">
                      <DocumentDownloadIcon className="h-5 w-5 mr-2" />
                      {resource.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          
          <div className="lg:col-span-1">
            <div className="bg-gray-50 rounded-lg p-4 h-full">
              <h3 className="text-xl font-bold text-gray-800 mb-4">Course Lessons</h3>
              <ul className="space-y-2">
                {course.lessons.map(lesson => (
                  <li key={lesson.id}>
                    <button
                      onClick={() => setCurrentLesson(lesson)}
                      className={`w-full text-left p-3 rounded-md transition-colors flex items-center justify-between ${currentLesson?.id === lesson.id ? 'bg-brand-primary text-white shadow' : 'hover:bg-gray-200'}`}
                    >
                      <div className="flex items-center">
                        <PlayIcon className={`h-5 w-5 mr-3 ${currentLesson?.id === lesson.id ? 'text-white' : 'text-gray-500'}`} />
                        <span className="font-medium">{lesson.title}</span>
                      </div>
                      <span className={`text-sm ${currentLesson?.id === lesson.id ? 'text-gray-200' : 'text-gray-500'}`}>{lesson.duration}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetail;