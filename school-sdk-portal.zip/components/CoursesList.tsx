
import React from 'react';
import { Course } from '../types';
import CourseCard from './CourseCard';

interface CoursesListProps {
  courses: Course[];
  onSelectCourse: (course: Course) => void;
}

const CoursesList: React.FC<CoursesListProps> = ({ courses, onSelectCourse }) => {
  return (
    <div>
      <h2 className="text-3xl font-bold text-gray-900 mb-6">Available Courses</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {courses.map(course => (
          <CourseCard key={course.id} course={course} onSelectCourse={onSelectCourse} />
        ))}
      </div>
    </div>
  );
};

export default CoursesList;
