
import React, { useState } from 'react';
import { User, Course } from '../types';
import Sidebar from './Sidebar';
import Header from './Header';
import CoursesList from './CoursesList';
import CourseDetail from './CourseDetail';
import Profile from './Profile';

interface DashboardProps {
  user: User;
  courses: Course[];
  onLogout: () => void;
}

type View = 'dashboard' | 'courses' | 'profile';

const Dashboard: React.FC<DashboardProps> = ({ user, courses, onLogout }) => {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  const handleSelectCourse = (course: Course) => {
    setSelectedCourse(course);
  };

  const handleBackToList = () => {
    setSelectedCourse(null);
  };
  
  const renderContent = () => {
    if (selectedCourse) {
      return <CourseDetail course={selectedCourse} onBack={handleBackToList} />;
    }

    switch (currentView) {
      case 'dashboard':
      case 'courses':
        return <CoursesList courses={courses} onSelectCourse={handleSelectCourse} />;
      case 'profile':
        return <Profile user={user} />;
      default:
        return <CoursesList courses={courses} onSelectCourse={handleSelectCourse} />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar onNavigate={setCurrentView} onLogout={onLogout} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header user={user} />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-8">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
