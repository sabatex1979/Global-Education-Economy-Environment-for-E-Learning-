
import React from 'react';
import { User } from '../types';

interface HeaderProps {
  user: User;
}

const Header: React.FC<HeaderProps> = ({ user }) => {
  return (
    <header className="bg-white shadow-sm p-4 flex justify-between items-center">
      <div>
        <h1 className="text-2xl font-bold text-gray-800">Welcome, {user.name.split(' ')[0]}!</h1>
        <p className="text-sm text-gray-500">Let's continue your learning journey.</p>
      </div>
      <div className="flex items-center">
        <span className="text-right mr-4">
          <div className="font-medium text-gray-800">{user.name}</div>
          <div className="text-sm text-gray-500">{user.email}</div>
        </span>
        <img
          className="h-12 w-12 rounded-full object-cover"
          src={user.avatarUrl}
          alt="User avatar"
        />
      </div>
    </header>
  );
};

export default Header;
