
import React from 'react';
import { User } from '../types';

interface ProfileProps {
  user: User;
}

const Profile: React.FC<ProfileProps> = ({ user }) => {
  return (
    <div>
      <h2 className="text-3xl font-bold text-gray-900 mb-6">My Profile</h2>
      <div className="bg-white p-8 rounded-lg shadow-md max-w-2xl mx-auto">
        <div className="flex flex-col items-center sm:flex-row">
          <img
            className="h-32 w-32 rounded-full object-cover ring-4 ring-brand-light"
            src={user.avatarUrl}
            alt="User avatar"
          />
          <div className="mt-4 sm:mt-0 sm:ml-8 text-center sm:text-left">
            <h3 className="text-2xl font-bold text-gray-900">{user.name}</h3>
            <p className="text-md text-gray-600">{user.email}</p>
            <p className="text-sm text-gray-500 mt-1">Student</p>
          </div>
        </div>
        <div className="border-t mt-8 pt-6">
          <h4 className="text-lg font-semibold text-gray-800 mb-4">Account Details</h4>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-500">Full Name</label>
              <p className="text-md text-gray-900">{user.name}</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-500">Email Address</label>
              <p className="text-md text-gray-900">{user.email}</p>
            </div>
             <div>
              <label className="block text-sm font-medium text-gray-500">Member Since</label>
              <p className="text-md text-gray-900">January 2024</p>
            </div>
             <button className="mt-4 bg-brand-primary text-white font-semibold py-2 px-4 rounded-lg hover:bg-brand-dark transition-colors">
              Edit Profile
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
