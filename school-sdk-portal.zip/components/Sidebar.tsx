
import React from 'react';
import { HomeIcon, BookOpenIcon, UserCircleIcon, LogoutIcon } from './Icons';

interface SidebarProps {
  onNavigate: (view: 'dashboard' | 'courses' | 'profile') => void;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onNavigate, onLogout }) => {
  const navItems = [
    { name: 'Dashboard', icon: HomeIcon, view: 'dashboard' as const },
    { name: 'Courses', icon: BookOpenIcon, view: 'courses' as const },
    { name: 'Profile', icon: UserCircleIcon, view: 'profile' as const },
  ];

  return (
    <div className="w-64 bg-white shadow-md flex flex-col">
      <div className="p-6 text-2xl font-bold text-brand-primary border-b">
        School Portal
      </div>
      <nav className="mt-6 flex-1">
        {navItems.map((item) => (
          <button
            key={item.name}
            onClick={() => onNavigate(item.view)}
            className="flex items-center w-full px-6 py-3 text-gray-600 hover:bg-brand-light hover:text-brand-primary transition-colors"
          >
            <item.icon className="h-6 w-6" />
            <span className="ml-4 font-medium">{item.name}</span>
          </button>
        ))}
      </nav>
      <div className="p-4 border-t">
        <button
          onClick={onLogout}
          className="flex items-center w-full px-4 py-3 text-gray-600 hover:bg-red-100 hover:text-red-600 rounded-lg transition-colors"
        >
          <LogoutIcon className="h-6 w-6" />
          <span className="ml-4 font-medium">Logout</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;