
import React from 'react';

interface VideoPlayerProps {
  videoUrl: string;
  title: string;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ videoUrl, title }) => {
  return (
    <div>
      <div className="aspect-video w-full bg-black rounded-lg overflow-hidden shadow-2xl">
        <video
          key={videoUrl}
          className="w-full h-full"
          controls
          autoPlay
        >
          <source src={videoUrl} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      <h2 className="text-2xl font-bold mt-4 text-gray-900">{title}</h2>
    </div>
  );
};

export default VideoPlayer;
