
import { User, Course } from './types';

export const MOCK_USER: User = {
  id: 'user-1',
  name: 'Alex Johnson',
  email: 'alex.j@example.com',
  avatarUrl: 'https://picsum.photos/seed/user1/100/100',
};

export const MOCK_COURSES: Course[] = [
  {
    id: 'course-1',
    title: 'Introduction to React Development',
    instructor: 'Dr. Evelyn Reed',
    description: 'Master the fundamentals of React and build modern, fast web applications.',
    longDescription: 'This comprehensive course covers everything from JSX and components to state management with hooks and context. You will build several projects to solidify your understanding and prepare for real-world development challenges. No prior React experience is necessary, but a good grasp of JavaScript is recommended.',
    imageUrl: 'https://picsum.photos/seed/react/600/400',
    lessons: [
      { id: 'l1-1', title: 'Course Introduction', duration: '5:30', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' },
      { id: 'l1-2', title: 'Setting Up Your Environment', duration: '12:15', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4' },
      { id: 'l1-3', title: 'Understanding JSX', duration: '15:45', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4' },
      { id: 'l1-4', title: 'Components and Props', duration: '22:00', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4' },
    ],
    resources: [
        { name: 'React Documentation', url: '#' },
        { name: 'Course Slides (PDF)', url: '#' },
    ]
  },
  {
    id: 'course-2',
    title: 'Advanced UI/UX Design Principles',
    instructor: 'Marcus Chen',
    description: 'Learn the principles of great design and create intuitive, beautiful user interfaces.',
    longDescription: 'Explore the theory and practice behind user-centered design. This course delves into topics like color theory, typography, layout, user research, and prototyping. You will learn to use industry-standard tools and techniques to design products that users love. A portfolio of your work will be developed throughout the course.',
    imageUrl: 'https://picsum.photos/seed/uiux/600/400',
    lessons: [
      { id: 'l2-1', title: 'The Psychology of Design', duration: '18:20', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4' },
      { id: 'l2-2', title: 'Color Theory and Application', duration: '25:10', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4' },
      { id: 'l2-3', title: 'Mastering Typography', duration: '20:55', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4' },
    ],
    resources: [
        { name: 'Design Principles Cheatsheet', url: '#' },
        { name: 'Figma Project File', url: '#' },
    ]
  },
  {
    id: 'course-3',
    title: 'Data Structures & Algorithms',
    instructor: 'Priya Sharma',
    description: 'A deep dive into the core concepts of data structures and algorithms.',
    longDescription: 'Prepare for technical interviews and become a more effective software engineer by mastering essential data structures like arrays, linked lists, trees, and graphs, along with fundamental algorithms for sorting, searching, and optimization. This course is heavy on practical examples and coding challenges.',
    imageUrl: 'https://picsum.photos/seed/dsa/600/400',
    lessons: [
      { id: 'l3-1', title: 'Big O Notation', duration: '14:30', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4' },
      { id: 'l3-2', title: 'Arrays and Linked Lists', duration: '28:00', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4' },
    ],
    resources: [
        { name: 'Algorithm Visualizer', url: '#' },
        { name: 'Problem Set 1', url: '#' },
    ]
  },
];
