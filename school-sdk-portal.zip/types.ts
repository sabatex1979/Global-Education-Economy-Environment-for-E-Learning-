
export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl: string;
}

export interface VideoLesson {
  id: string;
  title: string;
  duration: string;
  videoUrl: string;
}

export interface Course {
  id: string;
  title: string;
  instructor: string;
  description: string;
  longDescription: string;
  imageUrl: string;
  lessons: VideoLesson[];
  resources: { name: string; url: string }[];
}
